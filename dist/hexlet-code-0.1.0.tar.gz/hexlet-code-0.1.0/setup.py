# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['BRAIN_GAMES', 'BRAIN_GAMES.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = BRAIN_GAMES.scripts.brain_calc:main',
                     'brain-even = BRAIN_GAMES.scripts.brain_even:main',
                     'brain-games = BRAIN_GAMES.scripts.brain_games:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Fedor Pereverzev',
    'author_email': 'maphtown@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
